import type { SavedSessionSummary } from "@terminal-platform/runtime-types";
import type { WorkspaceSnapshot } from "@terminal-platform/workspace-core";

import { compactTerminalId } from "./terminal-identity.js";

export type TerminalSavedSessionPendingAction = "restore" | "delete";
export type TerminalSavedSessionsBulkAction = "prune";
export type TerminalSavedSessionRestoreStatus = "available" | "blocked" | "pending";
export type TerminalSavedSessionRestoreSemanticsTone = "ok" | "info" | "warning";

export interface TerminalSavedSessionRestoreSemanticsNote {
  code: string;
  label: string;
  detail: string;
  tone: TerminalSavedSessionRestoreSemanticsTone;
}

export interface TerminalSavedSessionsControlOptions {
  visibleSavedSessionCount: number;
  filterQuery?: string;
  pendingSavedSessionId: string | null;
  pendingSavedSessionAction: TerminalSavedSessionPendingAction | null;
  pendingBulkAction: TerminalSavedSessionsBulkAction | null;
  deleteConfirmationSessionId: string | null;
  pruneConfirmationArmed: boolean;
}

export interface TerminalSavedSessionItemControlState {
  session: SavedSessionSummary;
  title: string;
  compatibilityLabel: string;
  isPending: boolean;
  isRestoring: boolean;
  isDeleting: boolean;
  isConfirmingDelete: boolean;
  canRestore: boolean;
  canDelete: boolean;
  restoreStatus: TerminalSavedSessionRestoreStatus;
  restoreTitle: string;
  restoreSemanticsNotes: TerminalSavedSessionRestoreSemanticsNote[];
}

export interface TerminalSavedSessionsControlState {
  savedSessionCount: number;
  matchedSessionCount: number;
  filterQuery: string;
  isFiltered: boolean;
  visibleCount: number;
  hiddenCount: number;
  anyPending: boolean;
  isPruning: boolean;
  canShowMore: boolean;
  canCollapse: boolean;
  canPruneHidden: boolean;
  pruneKeepLatest: number;
  pruneConfirmationArmed: boolean;
  items: TerminalSavedSessionItemControlState[];
}

export const TERMINAL_SAVED_SESSIONS_DEFAULT_VISIBLE_COUNT = 4;

export function resolveTerminalSavedSessionsControlState(
  snapshot: WorkspaceSnapshot,
  options: TerminalSavedSessionsControlOptions,
): TerminalSavedSessionsControlState {
  const savedSessions = snapshot.catalog.savedSessions;
  const filterQuery = normalizeSavedSessionFilterQuery(options.filterQuery ?? "");
  const isFiltered = filterQuery.length > 0;
  const matchingSessions = isFiltered
    ? savedSessions.filter((session) => savedSessionMatchesFilter(session, filterQuery))
    : savedSessions;
  const visibleCount = clampVisibleSavedSessionCount(options.visibleSavedSessionCount, matchingSessions.length);
  const hiddenCount = matchingSessions.length - visibleCount;
  const anyPending = Boolean(options.pendingSavedSessionId || options.pendingBulkAction);
  const isPruning = options.pendingBulkAction === "prune";
  const pruneKeepLatest = visibleCount;

  return {
    savedSessionCount: savedSessions.length,
    matchedSessionCount: matchingSessions.length,
    filterQuery,
    isFiltered,
    visibleCount,
    hiddenCount,
    anyPending,
    isPruning,
    canShowMore: hiddenCount > 0,
    canCollapse: visibleCount > TERMINAL_SAVED_SESSIONS_DEFAULT_VISIBLE_COUNT,
    canPruneHidden: hiddenCount > 0 && !anyPending && !isFiltered,
    pruneKeepLatest,
    pruneConfirmationArmed: options.pruneConfirmationArmed,
    items: matchingSessions.slice(0, visibleCount).map((session) => toSavedSessionItemControlState(session, options, anyPending)),
  };
}

export function findRestorableSavedSession(
  snapshot: WorkspaceSnapshot,
  options: TerminalSavedSessionsControlOptions,
  sessionId: string,
): SavedSessionSummary | null {
  const controls = resolveTerminalSavedSessionsControlState(snapshot, {
    ...options,
    visibleSavedSessionCount: Math.max(options.visibleSavedSessionCount, snapshot.catalog.savedSessions.length),
  });
  return controls.items.find((item) => item.session.session_id === sessionId && item.canRestore)?.session ?? null;
}

export function hasSavedSession(
  snapshot: WorkspaceSnapshot,
  sessionId: string,
): boolean {
  return snapshot.catalog.savedSessions.some((session) => session.session_id === sessionId);
}

function toSavedSessionItemControlState(
  session: SavedSessionSummary,
  options: TerminalSavedSessionsControlOptions,
  anyPending: boolean,
): TerminalSavedSessionItemControlState {
  const title = session.title ?? compactTerminalId(session.session_id);
  const isPending = options.pendingSavedSessionId === session.session_id;
  const isRestoring = isPending && options.pendingSavedSessionAction === "restore";
  const isDeleting = isPending && options.pendingSavedSessionAction === "delete";
  const canRestore = Boolean(!anyPending && session.compatibility.can_restore);
  const canDelete = !anyPending;

  return {
    session,
    title,
    compatibilityLabel: savedSessionCompatibilityLabel(session),
    isPending,
    isRestoring,
    isDeleting,
    isConfirmingDelete: options.deleteConfirmationSessionId === session.session_id,
    canRestore,
    canDelete,
    restoreStatus: resolveRestoreStatus(session, anyPending),
    restoreTitle: restoreButtonTitle(session, title, anyPending),
    restoreSemanticsNotes: restoreSemanticsNotes(session),
  };
}

function clampVisibleSavedSessionCount(visibleCount: number, savedSessionCount: number): number {
  if (!Number.isFinite(visibleCount)) {
    return Math.min(TERMINAL_SAVED_SESSIONS_DEFAULT_VISIBLE_COUNT, savedSessionCount);
  }

  return Math.min(savedSessionCount, Math.max(0, Math.trunc(visibleCount)));
}

function normalizeSavedSessionFilterQuery(query: string): string {
  return query.trim().toLowerCase().replace(/\s+/g, " ");
}

function savedSessionMatchesFilter(session: SavedSessionSummary, filterQuery: string): boolean {
  const restoreSemanticsV2 = session.restore_semantics_v2;
  const searchableText = [
    session.title,
    session.session_id,
    compactTerminalId(session.session_id),
    session.route.backend,
    session.route.authority,
    session.compatibility.status,
    savedSessionCompatibilityLabel(session),
    restoreSemanticsV2?.restore_guarantee_level,
    restoreSemanticsV2?.history_replay_state,
    restoreSemanticsV2?.latest_restore_drill_status,
    ...(restoreSemanticsV2?.evidence_refs ?? []),
    `${session.tab_count} tabs`,
    `${session.pane_count} panes`,
  ]
    .filter((value): value is string => Boolean(value))
    .join(" ")
    .toLowerCase();

  return filterQuery.split(" ").every((term) => searchableText.includes(term));
}

function resolveRestoreStatus(
  session: SavedSessionSummary,
  anyPending: boolean,
): TerminalSavedSessionRestoreStatus {
  if (anyPending) {
    return "pending";
  }

  return session.compatibility.can_restore ? "available" : "blocked";
}

function restoreButtonTitle(session: SavedSessionSummary, title: string, anyPending: boolean): string {
  if (anyPending) {
    return "Wait for the current saved layout action to finish.";
  }

  const compatibilityLabel = savedSessionCompatibilityLabel(session);
  if (!session.compatibility.can_restore) {
    return `Cannot restore "${title}". ${compatibilityLabel}.`;
  }

  return `Restore saved layout "${title}". ${compatibilityLabel}.`;
}

function savedSessionCompatibilityLabel(session: SavedSessionSummary): string {
  switch (session.compatibility.status) {
    case "compatible":
      return "Compatible with this runtime";
    case "binary_skew":
      return "Compatible with a different binary version";
    case "format_version_unsupported":
      return "Saved layout format is unsupported";
    case "protocol_major_unsupported":
      return "Saved layout protocol major version is unsupported";
    case "protocol_minor_ahead":
      return "Saved layout was created by a newer protocol";
    default:
      return "Saved layout compatibility is unknown";
  }
}

function restoreSemanticsNotes(session: SavedSessionSummary): TerminalSavedSessionRestoreSemanticsNote[] {
  const semantics = session.restore_semantics;
  const semanticsV2 = session.restore_semantics_v2;
  const notes: TerminalSavedSessionRestoreSemanticsNote[] = [];

  if (semanticsV2) {
    notes.push(restoreGuaranteeNote(semanticsV2.restore_guarantee_level));
    notes.push(historyReplayStateNote(semanticsV2.history_replay_state));
    if (semanticsV2.latest_restore_drill_status) {
      notes.push(restoreDrillStatusNote(semanticsV2.latest_restore_drill_status));
    }

    if (semanticsV2.has_known_gaps) {
      notes.push({
        code: "history_gaps_known",
        label: "history gaps",
        detail: "Known missing history ranges are recorded for this saved layout.",
        tone: "warning",
      });
    }
  }

  if (semantics.restores_topology) {
    notes.push({
      code: "topology_restored",
      label: "topology",
      detail: "Pane and tab topology is restored.",
      tone: "ok",
    });
  } else {
    notes.push({
      code: "topology_not_restored",
      label: "topology unavailable",
      detail: "Pane and tab topology is not restored by this saved layout.",
      tone: "warning",
    });
  }

  if (!semantics.restores_focus_state) {
    notes.push({
      code: "focus_not_restored",
      label: "focus not restored",
      detail: "Focused tab or pane state is not restored.",
      tone: "info",
    });
  }

  if (!semantics.restores_tab_titles) {
    notes.push({
      code: "tab_titles_not_restored",
      label: "titles not restored",
      detail: "Saved tab titles are not restored.",
      tone: "info",
    });
  }

  if (!semantics.uses_saved_launch_spec) {
    notes.push({
      code: "launch_spec_unavailable",
      label: "launch unavailable",
      detail: "The original launch specification is not available for restore.",
      tone: "warning",
    });
  }

  if (!semantics.preserves_process_state) {
    notes.push({
      code: "process_state_not_preserved",
      label: "processes restart",
      detail: "Restore recreates topology and launch context, but not exact running process state.",
      tone: "warning",
    });
  }

  if (semantics.replays_saved_screen_buffers) {
    notes.push({
      code: "screen_buffers_replayed",
      label: "screen replay",
      detail: "Saved viewport history is reconstructed as historical output.",
      tone: "ok",
    });
  } else {
    notes.push({
      code: "screen_buffers_not_replayed",
      label: "no screen replay",
      detail: "Viewport history is not reconstructed from the saved snapshot.",
      tone: "info",
    });
  }

  return notes;
}

function restoreGuaranteeNote(
  guaranteeLevel: NonNullable<SavedSessionSummary["restore_semantics_v2"]>["restore_guarantee_level"],
): TerminalSavedSessionRestoreSemanticsNote {
  switch (guaranteeLevel) {
    case "rich_history":
      return {
        code: "restore_guarantee_rich_history",
        label: "rich history",
        detail: "Raw terminal stream evidence is available for historical restore.",
        tone: "ok",
      };
    case "basic_history":
      return {
        code: "restore_guarantee_basic_history",
        label: "basic history",
        detail: "Persisted command or stream evidence is available for restore.",
        tone: "ok",
      };
    case "visual_restore_only":
      return {
        code: "restore_guarantee_visual_restore_only",
        label: "visual restore",
        detail: "A saved visual snapshot is available without a raw replay guarantee.",
        tone: "info",
      };
    case "history_degraded":
      return {
        code: "restore_guarantee_history_degraded",
        label: "history degraded",
        detail: "Missing evidence or known gaps downgrade this saved layout.",
        tone: "warning",
      };
  }
}

function restoreDrillStatusNote(
  status: NonNullable<
    NonNullable<SavedSessionSummary["restore_semantics_v2"]>["latest_restore_drill_status"]
  >,
): TerminalSavedSessionRestoreSemanticsNote {
  switch (status) {
    case "passed":
      return {
        code: "restore_drill_passed",
        label: "drill passed",
        detail: "The latest restore drill completed successfully.",
        tone: "ok",
      };
    case "failed":
      return {
        code: "restore_drill_failed",
        label: "drill failed",
        detail: "The latest restore drill failed and the saved layout is degraded.",
        tone: "warning",
      };
    case "degraded":
      return {
        code: "restore_drill_degraded",
        label: "drill degraded",
        detail: "The latest restore drill completed with degraded history.",
        tone: "warning",
      };
    case "skipped":
      return {
        code: "restore_drill_skipped",
        label: "drill skipped",
        detail: "No restore drill proof is available for this saved layout.",
        tone: "info",
      };
    default:
      return {
        code: "restore_drill_unknown",
        label: "drill unknown",
        detail: "The latest restore drill returned an unknown status.",
        tone: "info",
      };
  }
}

function historyReplayStateNote(
  replayState: NonNullable<SavedSessionSummary["restore_semantics_v2"]>["history_replay_state"],
): TerminalSavedSessionRestoreSemanticsNote {
  switch (replayState) {
    case "not_available":
      return {
        code: "history_replay_not_available",
        label: "history unavailable",
        detail: "No durable history replay evidence is available.",
        tone: "warning",
      };
    case "snapshot_only":
      return {
        code: "history_replay_snapshot_only",
        label: "snapshot only",
        detail: "Restore can hydrate from a saved snapshot only.",
        tone: "info",
      };
    case "hydrated_from_snapshot":
      return {
        code: "history_replay_hydrated_from_snapshot",
        label: "snapshot hydrate",
        detail: "Restore uses a saved screen snapshot as historical context.",
        tone: "info",
      };
    case "replayed_from_journal":
      return {
        code: "history_replay_replayed_from_journal",
        label: "journal replay",
        detail: "History can be replayed from durable journal evidence.",
        tone: "ok",
      };
    case "partially_replayed_with_gaps":
      return {
        code: "history_replay_partially_replayed_with_gaps",
        label: "partial replay",
        detail: "History can be replayed with explicit missing ranges.",
        tone: "warning",
      };
  }
}
