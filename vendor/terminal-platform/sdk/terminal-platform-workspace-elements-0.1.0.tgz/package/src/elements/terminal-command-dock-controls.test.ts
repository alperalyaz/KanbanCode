import { describe, expect, it } from "vitest";

import type { BackendCapabilitiesInfo } from "@terminal-platform/runtime-types";
import { createInitialWorkspaceSnapshot, type WorkspaceSnapshot } from "@terminal-platform/workspace-core";

import {
  TERMINAL_COMMAND_DOCK_DEFAULT_RECENT_COMMAND_LIMIT,
  TERMINAL_COMMAND_DOCK_TERMINAL_RECENT_COMMAND_LIMIT,
  formatTerminalCommandSubmitInput,
  resolveTerminalCommandDockControlState,
} from "./terminal-command-dock-controls.js";

describe("terminal command dock controls", () => {
  it("formats submitted command drafts with carriage return for pty enter semantics", () => {
    expect(formatTerminalCommandSubmitInput("git status")).toBe("git status\r");
  });

  it("resolves command lane controls from focused workspace state", () => {
    const snapshot = createWorkspaceSnapshot({
      drafts: {
        "pane-1": "git status",
      },
      commandHistory: {
        entries: ["pwd", "ls -la", "git status", "npm test", "cargo test", "git diff"],
        limit: 50,
      },
    });

    const controls = resolveTerminalCommandDockControlState(snapshot, { pending: false });

    expect(controls.activeSessionId).toBe("session-1");
    expect(controls.activePaneId).toBe("pane-1");
    expect(controls.draft).toBe("git status");
    expect(controls.canSend).toBe(true);
    expect(controls.canInterrupt).toBe(true);
    expect(controls.canUsePane).toBe(true);
    expect(controls.canWriteInput).toBe(true);
    expect(controls.inputCapabilityStatus).toBe("known");
    expect(controls.canPasteClipboard).toBe(true);
    expect(controls.pasteCapabilityStatus).toBe("known");
    expect(controls.canSaveLayout).toBe(true);
    expect(controls.saveCapabilityStatus).toBe("known");
    expect(controls.recentCommands).toEqual([
      "git diff",
      "cargo test",
      "npm test",
      "git status",
      "ls -la",
    ]);
    expect(controls.recentCommandEntries.map(({ id, historyIndex, value }) => ({ id, historyIndex, value }))).toEqual([
      { id: "history-6", historyIndex: 5, value: "git diff" },
      { id: "history-5", historyIndex: 4, value: "cargo test" },
      { id: "history-4", historyIndex: 3, value: "npm test" },
      { id: "history-3", historyIndex: 2, value: "git status" },
      { id: "history-2", historyIndex: 1, value: "ls -la" },
    ]);
    expect(controls.recentCommands).toHaveLength(TERMINAL_COMMAND_DOCK_DEFAULT_RECENT_COMMAND_LIMIT);
  });

  it("caps recent command chips for terminal placement without changing command history", () => {
    const controls = resolveTerminalCommandDockControlState(
      createWorkspaceSnapshot({
        commandHistory: {
          entries: ["pwd", "ls -la", "git status", "npm test"],
          limit: 50,
        },
      }),
      {
        pending: false,
        recentCommandLimit: TERMINAL_COMMAND_DOCK_TERMINAL_RECENT_COMMAND_LIMIT,
      },
    );

    expect(controls.commandHistory).toEqual(["pwd", "ls -la", "git status", "npm test"]);
    expect(controls.recentCommands).toEqual(["npm test", "git status"]);
    expect(controls.recentCommandEntries.map((entry) => entry.id)).toEqual(["history-4", "history-3"]);
  });

  it("allows hosts to hide recent command chips for constrained placements", () => {
    const controls = resolveTerminalCommandDockControlState(
      createWorkspaceSnapshot({
        commandHistory: {
          entries: ["pwd", "ls -la"],
          limit: 50,
        },
      }),
      {
        pending: false,
        recentCommandLimit: 0,
      },
    );

    expect(controls.recentCommands).toEqual([]);
    expect(controls.recentCommandEntries).toEqual([]);
  });

  it("enables interrupt fallback only when focused pane terminal history exists", () => {
    const idleControls = resolveTerminalCommandDockControlState(
      createWorkspaceSnapshot({
        attachedSession: {
          ...createWorkspaceSnapshot().attachedSession,
          focused_screen: {
            ...createWorkspaceSnapshot().attachedSession!.focused_screen,
            surface: {
              title: "shell",
              cursor: null,
              lines: [{ text: "" }],
            },
          },
        },
      }),
      { pending: false },
    );
    const commandHistoryOnlyControls = resolveTerminalCommandDockControlState(
      createWorkspaceSnapshot({
        attachedSession: {
          ...createWorkspaceSnapshot().attachedSession,
          focused_screen: {
            ...createWorkspaceSnapshot().attachedSession!.focused_screen,
            surface: {
              title: "shell",
              cursor: null,
              lines: [{ text: "" }],
            },
          },
        },
        commandHistory: {
          entries: ["npm test"],
          limit: 50,
        },
      }),
      { pending: false },
    );
    const promptOnlyControls = resolveTerminalCommandDockControlState(
      createWorkspaceSnapshot({
        attachedSession: {
          ...createWorkspaceSnapshot().attachedSession,
          focused_screen: {
            ...createWorkspaceSnapshot().attachedSession!.focused_screen,
            surface: {
              title: "shell",
              cursor: null,
              lines: [{ text: "(venv312) ~/dev/quanta %" }],
            },
          },
        },
      }),
      { pending: false },
    );
    const visibleHistoryControls = resolveTerminalCommandDockControlState(createWorkspaceSnapshot(), { pending: false });
    const restoredHistoryControls = resolveTerminalCommandDockControlState(
      createWorkspaceSnapshot({
        attachedSession: {
          ...createWorkspaceSnapshot().attachedSession,
          focused_screen: {
            ...createWorkspaceSnapshot().attachedSession!.focused_screen,
            surface: {
              title: "shell",
              cursor: null,
              lines: [{ text: "" }],
            },
          },
        },
        historicalPanes: {
          "pane-1": {
            sessionId: "session-1",
            paneId: "pane-1",
            sourceSessionId: "session-1",
            sourcePaneId: "pane-1",
            lines: ["restored command output"],
            capturedAtMs: 1n,
            source: "v2_pane_history",
            replayStrategy: "full_history",
            restoreGuaranteeLevel: "basic_history",
            hasGaps: false,
            hasMoreSegments: false,
            fromEventSeq: null,
            nextEventSeq: null,
            segmentCount: 1,
            loadedPayloadBytes: 24n,
          },
        },
      }),
      { pending: false },
    );

    expect(idleControls.canInterrupt).toBe(false);
    expect(commandHistoryOnlyControls.canInterrupt).toBe(false);
    expect(promptOnlyControls.canInterrupt).toBe(false);
    expect(visibleHistoryControls.canInterrupt).toBe(true);
    expect(restoredHistoryControls.canInterrupt).toBe(true);
  });

  it("disables command input when loaded backend capabilities reject pane input writes", () => {
    const snapshot = createWorkspaceSnapshot({
      catalog: {
        ...createInitialWorkspaceSnapshot().catalog,
        backendCapabilities: {
          native: createCapabilities({ pane_input_write: false }),
        },
      },
      drafts: {
        "pane-1": "git status",
      },
    });

    const controls = resolveTerminalCommandDockControlState(snapshot, { pending: false });

    expect(controls.canUsePane).toBe(true);
    expect(controls.canWriteInput).toBe(false);
    expect(controls.canSend).toBe(false);
    expect(controls.canInterrupt).toBe(false);
    expect(controls.inputCapabilityStatus).toBe("known");
  });

  it("disables paste when loaded backend capabilities reject pane paste writes", () => {
    const snapshot = createWorkspaceSnapshot({
      catalog: {
        ...createInitialWorkspaceSnapshot().catalog,
        backendCapabilities: {
          native: createCapabilities({ pane_paste_write: false }),
        },
      },
    });

    const controls = resolveTerminalCommandDockControlState(snapshot, { pending: false });

    expect(controls.canUsePane).toBe(true);
    expect(controls.canPasteClipboard).toBe(false);
    expect(controls.pasteCapabilityStatus).toBe("known");
  });

  it("disables save layout when loaded backend capabilities reject explicit session saves", () => {
    const snapshot = createWorkspaceSnapshot({
      catalog: {
        ...createInitialWorkspaceSnapshot().catalog,
        backendCapabilities: {
          native: createCapabilities({ explicit_session_save: false }),
        },
      },
    });

    const controls = resolveTerminalCommandDockControlState(snapshot, { pending: false });

    expect(controls.activeSessionId).toBe("session-1");
    expect(controls.canSaveLayout).toBe(false);
    expect(controls.saveCapabilityStatus).toBe("known");
  });

  it("keeps command input enabled while capabilities are pending and a focused pane exists", () => {
    const snapshot = createWorkspaceSnapshot({
      catalog: {
        ...createInitialWorkspaceSnapshot().catalog,
        backendCapabilities: {},
      },
      drafts: {
        "pane-1": "git status",
      },
    });

    const controls = resolveTerminalCommandDockControlState(snapshot, { pending: false });

    expect(controls.canUsePane).toBe(true);
    expect(controls.canWriteInput).toBe(true);
    expect(controls.canSend).toBe(true);
    expect(controls.inputCapabilityStatus).toBe("unknown");
  });

  it("keeps paste enabled while capabilities are pending and a focused pane exists", () => {
    const snapshot = createWorkspaceSnapshot({
      catalog: {
        ...createInitialWorkspaceSnapshot().catalog,
        backendCapabilities: {},
      },
    });

    const controls = resolveTerminalCommandDockControlState(snapshot, { pending: false });

    expect(controls.canUsePane).toBe(true);
    expect(controls.canPasteClipboard).toBe(true);
    expect(controls.pasteCapabilityStatus).toBe("unknown");
  });

  it("keeps save layout disabled while capabilities are pending", () => {
    const snapshot = createWorkspaceSnapshot({
      catalog: {
        ...createInitialWorkspaceSnapshot().catalog,
        backendCapabilities: {},
      },
    });

    const controls = resolveTerminalCommandDockControlState(snapshot, { pending: false });

    expect(controls.activeSessionId).toBe("session-1");
    expect(controls.canSaveLayout).toBe(false);
    expect(controls.saveCapabilityStatus).toBe("unknown");
  });

  it("disables all pane actions while pending", () => {
    const controls = resolveTerminalCommandDockControlState(createWorkspaceSnapshot(), { pending: true });

    expect(controls.canSend).toBe(false);
    expect(controls.canInterrupt).toBe(false);
    expect(controls.canUsePane).toBe(false);
    expect(controls.canWriteInput).toBe(false);
    expect(controls.canPasteClipboard).toBe(false);
    expect(controls.canSaveLayout).toBe(false);
  });
});

function createWorkspaceSnapshot(overrides: Partial<WorkspaceSnapshot> = {}): WorkspaceSnapshot {
  const base = createInitialWorkspaceSnapshot();
  return {
    ...base,
    connection: {
      state: "ready",
      handshake: null,
      lastError: null,
    },
    catalog: {
      ...base.catalog,
      backendCapabilities: {
        native: createCapabilities({}),
      },
    },
    selection: {
      activeSessionId: "session-1",
      activePaneId: null,
    },
    attachedSession: {
      session: {
        session_id: "session-1",
        route: {
          backend: "native",
          authority: "local_daemon",
          external: null,
        },
        title: "SDK shell",
      },
      health: {
        session_id: "session-1",
        phase: "ready",
        can_attach: true,
        invalidated: false,
        reason: null,
        detail: null,
      },
      topology: {
        session_id: "session-1",
        backend_kind: "native",
        focused_tab: "tab-1",
        tabs: [
          {
            tab_id: "tab-1",
            title: "shell",
            focused_pane: "pane-1",
            root: { kind: "leaf", pane_id: "pane-1" },
          },
        ],
      },
      focused_screen: {
        pane_id: "pane-1",
        sequence: 1n,
        rows: 24,
        cols: 80,
        source: "native_emulator",
        surface: {
          title: "shell",
          cursor: null,
          lines: [{ text: "ready" }],
        },
      },
    },
    ...overrides,
  };
}

function createCapabilities(
  overrides: Partial<BackendCapabilitiesInfo["capabilities"]>,
): BackendCapabilitiesInfo {
  return {
    backend: "native",
    capabilities: {
      tiled_panes: true,
      floating_panes: false,
      split_resize: true,
      tab_create: true,
      tab_close: true,
      tab_focus: true,
      tab_rename: true,
      session_scoped_tab_refs: true,
      session_scoped_pane_refs: true,
      pane_split: true,
      pane_close: true,
      pane_focus: true,
      pane_input_write: true,
      pane_paste_write: true,
      raw_output_stream: false,
      rendered_viewport_stream: true,
      rendered_viewport_snapshot: true,
      rendered_scrollback_snapshot: false,
      layout_dump: true,
      layout_override: true,
      read_only_client_mode: false,
      explicit_session_save: true,
      explicit_session_restore: true,
      plugin_panes: false,
      advisory_metadata_subscriptions: true,
      independent_resize_authority: true,
      ...overrides,
    },
  };
}
